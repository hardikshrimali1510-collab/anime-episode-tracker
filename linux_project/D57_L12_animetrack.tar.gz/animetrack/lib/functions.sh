#!/bin/bash

DATA="data/anime.csv"
LOG="logs/activity.log"

mkdir -p logs reports backups

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $*" >> "$LOG"
}

check_data() {
    if [ ! -f "$DATA" ]; then
        echo "Data not found: $DATA"
        return 1
    fi
}

show_help() {
    echo "Usage: ./main.sh"
    echo "       ./main.sh --help"
    echo "       ./main.sh --backup"
    echo "       ./main.sh --cron"
}

view_data() {
    check_data || return
    cat -n "$DATA"
}

do_backup() {
    local f="backups/data_$(date +%Y%m%d_%H%M%S).tar.gz"
    if tar -czf "$f" data/; then
        echo "Backup saved: $f ($(du -h "$f" | cut -f1))"
        log "Backup created: $f"
    else
        echo "Backup failed."
        return 1
    fi
}

view_log() {
    if [ -f "$LOG" ]; then
        tail -n 15 "$LOG"
    else
        echo "No activity yet."
    fi
}

# FEATURE 1: Update episodes watched
feature_1() {
    check_data || return
    echo "== Update episodes watched =="
    read -r -p "Enter anime title (exact name): " title

    if ! awk -F',' -v t="$title" 'NR>1 && $1==t {found=1} END {exit !found}' "$DATA"; then
        echo "Anime not found: $title"
        log "Update failed: anime not found: $title"
        return 1
    fi

    local total watched status tmp
    total=$(awk -F',' -v t="$title" 'NR>1 && $1==t {print $2; exit}' "$DATA")
    read -r -p "Enter episodes watched (0-$total): " watched

    if ! [[ "$watched" =~ ^[0-9]+$ ]] || (( watched > total )); then
        echo "Invalid number. Enter a whole number from 0 to $total."
        log "Update failed: invalid episode count for $title"
        return 1
    fi

    if (( watched == total )); then
        status="completed"
    else
        status=$(awk -F',' -v t="$title" 'NR>1 && $1==t {print $4; exit}' "$DATA")
        [[ "$status" == "completed" ]] && status="watching"
    fi

    tmp=$(mktemp) || return 1
    awk -F',' -v OFS=',' -v t="$title" -v w="$watched" -v s="$status" '
        NR==1 {print; next}
        $1==t {$3=w; $4=s}
        {print}
    ' "$DATA" > "$tmp" && mv "$tmp" "$DATA"
    echo "Updated: $title — $watched/$total episodes ($status)"
    log "Updated $title to $watched/$total episodes; status=$status"
}

# FEATURE 2: Progress percentage and text bar
feature_2() {
    check_data || return
    echo "== Anime progress =="
    awk -F',' 'NR>1 && $2 ~ /^[0-9]+$/ && $2>0 && $3 ~ /^[0-9]+$/ {
        pct=int(($3*100/$2)+0.5)
        filled=int((pct+2)/5)
        if (filled>20) filled=20
        bar=""
        for (i=0; i<filled; i++) bar=bar "#"
        for (i=filled; i<20; i++) bar=bar "-"
        printf "%-25s [%s] %3d%% (%d/%d)\n", $1, bar, pct, $3, $2
    }' "$DATA"
    log "Displayed progress bars"
}

# FEATURE 3: Completed and dropped anime
feature_3() {
    check_data || return
    echo "== Completed and dropped series =="
    awk -F',' 'NR==1 {next}
        tolower($4)=="completed" || tolower($4)=="dropped" {
            printf "%-25s Watched: %s/%s  Status: %s\n", $1, $3, $2, $4
            found=1
        }
        END {if (!found) print "No completed or dropped anime found."}
    ' "$DATA"
    log "Listed completed and dropped series"
}

# FEATURE 4: Remaining binge time (24 minutes per episode)
feature_4() {
    check_data || return
    echo "== Remaining binge time (24 minutes per episode) =="
    if ! command -v bc >/dev/null 2>&1; then
        echo "bc is not installed. Install it with: sudo apt install bc"
        return 1
    fi
    awk -F',' 'NR>1 && $2 ~ /^[0-9]+$/ && $3 ~ /^[0-9]+$/ {
        remaining=$2-$3
        if (remaining<0) remaining=0
        printf "%s|%d\n", $1, remaining
    }' "$DATA" | while IFS='|' read -r title remaining; do
        minutes=$(echo "$remaining * 24" | bc)
        hours=$(echo "scale=2; $minutes / 60" | bc)
        printf "%-25s %s episodes left — %s minutes (~%s hours)\n" "$title" "$remaining" "$minutes" "$hours"
    done
    log "Estimated remaining binge time"
}

# FEATURE 5: Sort by percentage watched, highest first
feature_5() {
    check_data || return
    echo "== Sort series by progress (highest first) =="
    awk -F',' 'NR>1 && $2 ~ /^[0-9]+$/ && $2>0 && $3 ~ /^[0-9]+$/ {
        pct=($3*100/$2)
        printf "%.4f,%s,%s/%s,%d%%\n", pct, $1, $3, $2, int(pct+0.5)
    }' "$DATA" |
    sort -t',' -k1,1nr |
    awk -F',' 'BEGIN {printf "%-25s %-12s %s\n","Title","Watched","Progress"}
        {printf "%-25s %-12s %s\n",$2,$3,$4}'
    log "Sorted anime by progress"
}

# CRON TASK: Save a progress summary when called by cron
cron_task() {
    check_data || return
    {
        echo "Anime progress summary — $(date '+%Y-%m-%d %H:%M:%S')"
        awk -F',' 'NR>1 && $2 ~ /^[0-9]+$/ && $2>0 && $3 ~ /^[0-9]+$/ {
            pct=int($3*100/$2+0.5)
            printf "%s: %d%% (%s/%s) — %s\n", $1, pct, $3, $2, $4
        }' "$DATA"
        echo
    } >> reports/progress.log
    echo "Progress summary saved to reports/progress.log"
    log "Cron progress summary created"
}
